import { Component, Input } from "@angular/core";
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-createproduct',
    templateUrl: './createProduct.component.html',
    styleUrls: ['./createProduct.component.css']
})
export class CreateProductComponent {
    constructor(private http: HttpClient) { }
    product={}
    submit() {
        let url = "https://learningmeanwithashu.herokuapp.com/api/createproduct";
        console.log(this.product);
        this.http.post(url, this.product).subscribe((data) => {
            console.log(data);
        }, (error) => {
            console.log(error);
        })
    }
}